export default function ATSScore({ score }) {
  const color =
    score >= 80
      ? 'text-yellow-400'
      : score >= 60
      ? 'text-amber-300'
      : 'text-red-400';

  return (
    <div className="card text-center">
      <p className="text-sm text-zinc-400">
        ATS Score
      </p>

      <p className={`text-6xl font-bold mt-2 ${color}`}>
        {score}
      </p>

      <p className="text-xs text-zinc-500 mt-1">
        / 100
      </p>
    </div>
  );
}