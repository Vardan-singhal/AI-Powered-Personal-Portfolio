import { Link } from 'react-router-dom';
import {
  FiGithub,
  FiLinkedin,
  FiMail,
} from 'react-icons/fi';

export default function Footer() {
  return (
    <footer className="border-t border-yellow-500/10 bg-black/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-6 py-12">

        <div className="grid md:grid-cols-3 gap-10">

          {/* Brand */}
          <div>
            <h3 className="text-xl font-bold bg-grad-hero bg-clip-text text-transparent">
              Vardan Singhal
            </h3>

            <p className="mt-4 text-zinc-400 text-sm leading-relaxed">
              Full Stack Developer specializing in MERN Stack,
              AI-powered applications, modern web experiences,
              and scalable backend systems.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-yellow-300 mb-4">
              Quick Links
            </h4>

            <div className="flex flex-col gap-2 text-zinc-400 text-sm">
              <Link to="/" className="hover:text-yellow-300 transition">
                Home
              </Link>

              <Link to="/about" className="hover:text-yellow-300 transition">
                About
              </Link>

              <Link to="/projects" className="hover:text-yellow-300 transition">
                Projects
              </Link>

              <Link to="/skills" className="hover:text-yellow-300 transition">
                Skills
              </Link>

              <Link to="/experience" className="hover:text-yellow-300 transition">
                Experience
              </Link>

              <Link to="/contact" className="hover:text-yellow-300 transition">
                Contact
              </Link>
            </div>
          </div>

          {/* Socials */}
          <div>
            <h4 className="font-semibold text-yellow-300 mb-4">
              Connect
            </h4>

            <div className="flex gap-5 text-xl text-zinc-400">

              <a
                href="https://github.com/Vardan-singhal"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-yellow-300 transition"
              >
                <FiGithub />
              </a>

              <a
                href="https://www.linkedin.com/in/vardan-singhal-612476214/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-yellow-300 transition"
              >
                <FiLinkedin />
              </a>

              <a
                href="mailto:vardansinghal30@gmail.com"
                className="hover:text-yellow-300 transition"
              >
                <FiMail />
              </a>

            </div>

            <p className="mt-4 text-sm text-zinc-400">
              Open to Frontend, MERN Stack and Full Stack opportunities.
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-yellow-500/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-zinc-500">

          <p>
            © {new Date().getFullYear()} Vardan Singhal.
            All rights reserved.
          </p>

          <p>
            Built with React • Node.js • MongoDB • Express • AI
          </p>

        </div>
      </div>
    </footer>
  );
}